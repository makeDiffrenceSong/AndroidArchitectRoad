package com.enjoy.diff.android;

public class MapList {
    
}
