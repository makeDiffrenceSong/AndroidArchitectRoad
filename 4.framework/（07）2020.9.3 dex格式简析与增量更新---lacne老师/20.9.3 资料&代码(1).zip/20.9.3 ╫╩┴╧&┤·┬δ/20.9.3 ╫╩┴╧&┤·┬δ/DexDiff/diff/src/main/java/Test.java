public class Test {

    public static void test() {
        System.out.println("a2");
        System.out.println("b2");
        System.out.println("c2");
        System.out.println("d2");
        System.out.println("e2");
        System.out.println("f2");
        System.out.println("g2");
        System.out.println("h2");
        System.out.println("i2");
    }

}
